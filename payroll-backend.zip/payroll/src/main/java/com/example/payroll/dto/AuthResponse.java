package com.example.payroll.dto;

import com.example.payroll.model.User;

public class AuthResponse {
    private String token;
    private String username;
    private User.Role role;

    public AuthResponse(String token, User user) {
        this.token = token;
        this.username = user.getUsername();
        this.role = user.getRole();
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public User.Role getRole() { return role; }
    public void setRole(User.Role role) { this.role = role; }
}
