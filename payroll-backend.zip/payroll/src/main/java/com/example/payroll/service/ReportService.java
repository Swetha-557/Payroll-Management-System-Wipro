package com.example.payroll.service;

import org.springframework.stereotype.Service;

@Service
public class ReportService {

    public String getPayrollSummary() {
        return "Payroll summary report";
    }

    public String getDepartmentCostReport() {
        return "Department cost report";
    }
}
