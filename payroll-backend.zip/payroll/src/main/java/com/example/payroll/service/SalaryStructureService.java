package com.example.payroll.service;

import com.example.payroll.model.SalaryStructure;
import com.example.payroll.model.Employee;
import com.example.payroll.repository.SalaryStructureRepository;
import com.example.payroll.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalaryStructureService {

    @Autowired
    private SalaryStructureRepository salaryStructureRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<SalaryStructure> getSalaryStructuresByEmployee(Long employeeId) {
        return salaryStructureRepository.findByEmployeeId(employeeId);
    }

    public SalaryStructure assignSalaryStructure(Long employeeId, SalaryStructure structure) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        structure.setEmployee(employee);
        return salaryStructureRepository.save(structure);
    }
}
