package com.example.payroll.service;

import com.example.payroll.model.Payroll;
import com.example.payroll.model.Employee;
import com.example.payroll.repository.PayrollRepository;
import com.example.payroll.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PayrollService {

    @Autowired
    private PayrollRepository payrollRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    public Payroll createPayroll(Payroll payroll) {
        // Calculate net salary
        double net = (payroll.getBasicSalary() != null ? payroll.getBasicSalary() : 0)
                   + (payroll.getBonus() != null ? payroll.getBonus() : 0)
                   - (payroll.getDeductions() != null ? payroll.getDeductions() : 0);
        payroll.setNetSalary(net);

        return payrollRepository.save(payroll);
    }

    public List<Payroll> getAllPayroll() {
        return payrollRepository.findAll();
    }

    public List<Payroll> getPayrollByEmployee(Long employeeId) {
        return payrollRepository.findByEmployeeId(employeeId);
    }

    public Payroll getPayrollById(Long id) {
        return payrollRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Payroll not found with id " + id));
    }
}
