package com.example.payroll.controller;

import com.example.payroll.model.Employee;
import com.example.payroll.model.SalaryStructure;
import com.example.payroll.service.EmployeeService;
import com.example.payroll.service.SalaryStructureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private SalaryStructureService salaryStructureService;

    // ✅ GET all employees
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeService.getAllEmployees());
    }

    // ✅ POST new employee
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.createEmployee(employee));
    }

    // ✅ GET employee by ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }

    // ✅ PUT update employee
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        return ResponseEntity.ok(employeeService.updateEmployee(id, employee));
    }

    // ✅ GET employee salary structures
    @GetMapping("/{id}/salary-structures")
    public ResponseEntity<List<SalaryStructure>> getEmployeeSalaryStructures(@PathVariable Long id) {
        return ResponseEntity.ok(salaryStructureService.getSalaryStructuresByEmployee(id));
    }

    // ✅ POST assign salary structure to employee
    @PostMapping("/{id}/salary-structures")
    public ResponseEntity<SalaryStructure> assignSalaryStructure(@PathVariable Long id,
                                                                 @RequestBody SalaryStructure structure) {
        return ResponseEntity.ok(salaryStructureService.assignSalaryStructure(id, structure));
    }
}
