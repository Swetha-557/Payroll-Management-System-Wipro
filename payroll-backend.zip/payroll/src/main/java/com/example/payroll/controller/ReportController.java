package com.example.payroll.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/reports")
public class ReportController {

    @GetMapping("/payroll-summary")
    public ResponseEntity<String> getPayrollSummary() {
        return ResponseEntity.ok("Payroll summary report");
    }

    @GetMapping("/department-cost")
    public ResponseEntity<String> getDepartmentCostReport() {
        return ResponseEntity.ok("Department cost report");
    }
}
