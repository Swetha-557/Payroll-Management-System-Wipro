package com.example.payroll.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.security.Key;

@Component
public class JwtTokenProvider {

  private final Key key;
  private final long validityInMilliseconds;

  public JwtTokenProvider(@Value("${app.jwtSecret}") String secret,
                          @Value("${app.jwtExpirationMs}") long jwtExpirationMs) {
    this.key = Keys.hmacShaKeyFor(secret.getBytes());
    this.validityInMilliseconds = jwtExpirationMs;
  }

  public String createToken(String username, String role) {
	    Date now = new Date();
	    Date expiry = new Date(now.getTime() + validityInMilliseconds);

	    return Jwts.builder()
	        .setSubject(username)
	        .claim("role", role)
	        .setIssuedAt(now)
	        .setExpiration(expiry)
	        .signWith(key, SignatureAlgorithm.HS256) // ✅ specify algorithm!
	        .compact();
	}

  public boolean validateToken(String token) {
    try {
      Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
      return true;
    } catch (JwtException | IllegalArgumentException e) {
      return false;
    }
  }

  public String getUsername(String token) {
    return Jwts.parserBuilder().setSigningKey(key).build()
            .parseClaimsJws(token).getBody().getSubject();
  }
}
