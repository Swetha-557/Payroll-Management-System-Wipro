package com.example.payroll.controller;

import com.example.payroll.model.LeaveRequest;
import com.example.payroll.repository.LeaveRequestRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/leaves")
public class LeaveController {
  private final LeaveRequestRepository repo;

  public LeaveController(LeaveRequestRepository repo) { this.repo = repo; }

  @PostMapping
  public ResponseEntity<LeaveRequest> apply(@RequestBody LeaveRequest req) {
    req.setStatus(LeaveRequest.Status.PENDING);
    return ResponseEntity.ok(repo.save(req));
  }

  @GetMapping
  public ResponseEntity<List<LeaveRequest>> list() { return ResponseEntity.ok(repo.findAll()); }

  @PostMapping("/{id}/approve")
  public ResponseEntity<?> approve(@PathVariable Long id) {
    LeaveRequest r = repo.findById(id).orElseThrow();
    r.setStatus(LeaveRequest.Status.APPROVED);
    repo.save(r);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/{id}/reject")
  public ResponseEntity<?> reject(@PathVariable Long id) {
    LeaveRequest r = repo.findById(id).orElseThrow();
    r.setStatus(LeaveRequest.Status.REJECTED);
    repo.save(r);
    return ResponseEntity.ok().build();
  }
}
